"""
File: most_artistic_award.py
----------------------------------
This file creates a photoshopped image
that is going to compete for the most artistic award for stanCodeXNCTU MSE Fall 2020.
Please put all the images you will use in the image_contest folder
and make sure to choose the right folder when loading your images.
"""
